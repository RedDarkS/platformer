# platformer

https://RedDarkS.github.io/platformer/

- To advance in the game, use the keys : 'ArrowRight' or 'D'.
- You can jump with the key : 'ArrowUp' or 'Z' or 'Space'.
- Press 'R' for a newGame.

TODO list :

A Faire / Finir :

- Menu du jeu.
- Conditions de victoire.
- Sons.
- Event durant le niveau.
- Faire et intégrer le décor.
- Faire et intégrer les sprites (Chevalier, Archer, Mage, Markus, Lyra).
- Faire des animations pour les sprites.
- Particules des planches : à la destruction durant x secondes.
- IA des ennemis (Markus, Chevalier, Archer, Mage).
- Adapter, agrandir et corriger le level design.
- débugger la chute des planches (glitch dans le sol si on est en dessous)

Fait :

- Sprite des torches
- Animation des torches
- Particules des torches
- Animation du player
- Grimper.
- Destruction des planches.
- Particules des collectibles : uniquement quand ramassé, durant x secondes.
